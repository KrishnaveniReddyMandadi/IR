use strict;
use Lingua::Stem::En;

my $dir = $ARGV[0];
my @files = glob( $dir . '/*' );
#clean up stop words, url, remove upper case, remove digits, remove punctuations, Use of Porter Stemmers logic to remove morphological variations
my @stop_words=split(/\n/, `curl -s  https://cs.memphis.edu/~vrus/teaching/ir-websearch/papers/english.stopwords.txt`);

sub cleanup_line{
	#print "Line : @_ \n";
	my @words_init = split(' ', $_[0]);
	my @words_final;
	foreach my $word (@words_init){
		my $lc_word = lc($word);
		next if ( grep( /^\Q$lc_word\E$/, @stop_words ) ); ##Check for stop words
		next if ($word =~ /^(?:(?:http?|s?ftp))/i);  ##Check for url 
		next if ($word =~ /[<>]/);  ##Check for html contents - Mostly looking for < and >
		next if ($word =~ /[A-Z]/); ##Remove words having upper case
		$word =~ s/[0-9]//g;   ##Remove digits
		$word =~ s/[[:punct:]]//g;  ##Remove punctuations
		####Use of Porter Stemmers logic to remove morphological variations
		my $stemword=Lingua::Stem::En::stem( {-words => [$word] });
		push(@words_final, @$stemword) unless grep{$_ eq @$stemword} @words_final;
	}
	return @words_final
}

sub preprocess_file{
	my $file=$_[0];
	open my $handle, '<', $file;
	my @all_words;
	(my @lines = <$handle>);
	close $handle;
	foreach my $line (@lines){
		#print "Line : $line \n";
		my @wrds=cleanup_line($line);
		#print "@wrds\n";
		push (@all_words, @wrds)
	}
	my %hash   = map { $_, 1 } @all_words;
	my @uniq_words = keys %hash;
	#print "@uniq_words\n";
	return sort @uniq_words;
}


open(FH, '>', "out_file.log" ) or die $!;

#print "Files found for pre-processing: \n @files \n";
print "Preprocessing text files in folder $ARGV[0]\n";
foreach my $file (@files){
	if ($file =~ m/.txt$/){
		print "$file\n";
		my @words_in_file=preprocess_file($file);
		print FH "Words contained in File - $file are \n";
		print FH join("\n", @words_in_file), "\n";
	}
}
print "Done\n";
print "Output in out_file.log\n";
close (FH)
