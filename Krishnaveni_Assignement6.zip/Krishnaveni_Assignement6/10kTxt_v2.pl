use strict;
use LWP::UserAgent;
use HTML::FormatText;
use CAM::PDF;
use open ':std', ':encoding(UTF-8)';


my @file_links;
my @old_links;
my @new_links;

sub get_text {
        ####To get test from URL
        my $url=$_[0];
        #From LWP tutorial
        #my $ua = new LWP::UserAgent;
        #$ua->timeout(120);
        #my $request = new HTTP::Request('GET', $url);
        #my $response = $ua->request($request);
        #my $content = $response->content();
		my $content = "";
		if ( $url =~ m/.pdf$/ ){
			#my $resp = LWP::Simple("$url",'sample.pdf');
			`curl -s $url -o sample.pdf`;
			my $pdfone = CAM::PDF->new('sample.pdf');
			#	my $content=$pdf->toString();
			for my $page (1 .. $pdfone->numPages()) {
				my $text = $pdfone->getPageText($page);
				$content = $content . $text ; 
			
		 }
		}
		else {
			$content =`curl -s  $url`;
		}
        #From FormatText sample in the module
        my $string = HTML::FormatText->format_string(
        $content,
        leftmargin => 0, rightmargin => 50
        );
        return $string;
}
sub get_all_text {
        ####To get test from URL
        my $url=$_[0];
        #From LWP tutorial
        my $ua = new LWP::UserAgent;
        $ua->timeout(120);
        my $request = new HTTP::Request('GET', $url);
        my $response = $ua->request($request);
        my $content = $response->content();
        return $content ;
}
sub get_links{
	my $lnk=$_[0];
	my @content = split(/\n/, `curl -s  $lnk`);
	my @links = grep(/<a.*href=.*>/,@content);
	my $link;
	foreach my $c (@links){
        #source https://stackoverflow.com/questions/254345/how-can-i-extract-url-and-link-text-from-html-in-perl
		$c =~ /<a.*href="([\s\S]+?)".*>/;
		$link = $1;
		$link =~ s/#.*//;
		next if $link eq "";
		if ( ($link =~ m/.txt$/ || $link =~ m/.html$/ || $link =~ m/.pdf$/ || $link =~ m/.php$/ ) ) {
			if ($link =~ m/^(?!http)/ ){
				$link = $lnk . "/" . $link;
			}
			if (index($link, $lnk) ) {
				#printf "File found $link \n";
				push(@file_links, $link) unless grep{$_ eq $link} @file_links;
			}
		}
		else{
				if (index($link, $lnk)  ) {
				next if grep{$_ eq $link} @old_links;
				push(@new_links, $link) unless grep{$_ eq $link} @new_links;
				#					print "New Link found: $link \n";
			}
		}
  }
}

my $prv_lnk=$ARGV[0];
printf "Link provided : $prv_lnk \n";
get_links($prv_lnk);
#print "New Links : @new_links\n";
#print "File Links @file_links";
if (scalar @new_links == 0 ){
	print "Provided link does not have any child links."
}

do {{
 # get the next array element
 my $link = shift(@new_links);	
 push(@old_links, $link);
 get_links($link); 
}}until(!scalar @new_links > 0 || scalar @file_links >100);

#print "File Links @file_links";
my $file_cnt=226;
####Looping though child links
foreach my $file_lnk (@file_links){
        my $file_text = get_text($file_lnk);
		my $txtfile="Doc_".$file_cnt.".txt";
        open (FH, '>' , $txtfile) or die $!;
        printf FH "Document Link : $file_lnk\n";
		printf FH "\n";
        printf FH "$file_text \n";
		close (FH);
$file_cnt++
}

