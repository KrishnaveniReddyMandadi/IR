use strict;
use LWP::UserAgent;
use HTML::FormatText;


sub get_text {
	####To get test from URL
	my $url=$_[0];
	#From LWP tutorial
	my $ua = new LWP::UserAgent;
	$ua->timeout(120);
	my $request = new HTTP::Request('GET', $url);
	my $response = $ua->request($request);
	my $content = $response->content();
	#From FormatText sample in the module
	my $string = HTML::FormatText->format_string(
        $content,
        leftmargin => 0, rightmargin => 50
        );
	return $string;
}

sub count_of_words{
	#To get the frequecy of each word in the given text
	#From https://perlmaven.com/count-words-in-text-using-perl
	my %count;
	my $string=$_[0];
	foreach my $str ($string =~ /\w+/g ){
        $count{$str}++;
    }
	return %count;
}


sub get_all_text {
	####To get test from URL
	my $url=$_[0];
	#From LWP tutorial
	my $ua = new LWP::UserAgent;
	$ua->timeout(120);
	my $request = new HTTP::Request('GET', $url);
	my $response = $ua->request($request);
	my $content = $response->content();
	return $content;
}
my $lnk=$ARGV[0];

printf "Link provided : $lnk \n";

printf "Preparing word count list\n";
my $text = get_text($lnk);
my %txt_cnt = count_of_words($text);

my %doc_cnt;


open(FH, '>', "test_out_file.txt" ) or die $!;

foreach my $str (sort keys %txt_cnt) {
    printf FH "%-31s %s\n", $str, $txt_cnt{$str};
    $doc_cnt{$str}++;
}



printf "Fetching links in main page\n";
####To get links present in the main page
my @content = split(/\n/,get_all_text($lnk));
#print "@content";
my @links = grep(/<a.*href=.*>/,@content);
my $link;
my @chld_links;
foreach my $c (@links){
	#source https://stackoverflow.com/questions/254345/how-can-i-extract-url-and-link-text-from-html-in-perl
  $c =~ /<a.*href="([\s\S]+?)".*>/;
  $link = $1;
  $link =~ s/#.*//;
    if ( $link =~ m/^(?!http)/ && $link =~m/.txt$/) {
          $link = $lnk . "/" . $link
          }
    print "$link\n";
  ##Checking if retrieved link is directly linked to the main page
  if (index($link, $lnk) != -1) {
	  push(@chld_links, $link) unless grep{$_ eq $link} @chld_links;
  }
}

printf "Preparing word count list for child links\n";

my $lnk_cnt=0;
####Looping though child links
foreach my $chld_lnk (@chld_links){
	my $chld_text = get_text($chld_lnk);
	my %chld_text_cnt = count_of_words($chld_text);
	printf FH "\n";
	printf FH "Child Page : $chld_lnk\n";
	foreach my $str (sort keys %chld_text_cnt) {
 	   printf FH "%-31s %s\n", $str, $chld_text_cnt{$str};
	   $doc_cnt{$str}++;
	}
$lnk_cnt++
}

printf "Child Link Count: $lnk_cnt\n";
printf FH "\n";
printf FH "Doc count for each word\n";
foreach my $str (sort keys %doc_cnt) {
    printf FH "%-31s %s\n", $str, $doc_cnt{$str};
}
close (FH);

printf "Output Path : test_out_file.txt";