use strict;
use Lingua::Stem::En;

my $dir = $ARGV[0];
my @files = glob( $dir . '/*' );

my @stop_words=split(/\n/, `curl -s  https://cs.memphis.edu/~vrus/teaching/ir-websearch/papers/english.stopwords.txt`);

sub cleanup_line{
	#print "Line : @_ \n";
	my @words_init = split(' ', $_[0]);
	my %count;
	foreach my $word (@words_init){
		my $lc_word = lc($word);
		next if ( grep( /^\Q$lc_word\E$/, @stop_words ) ); ##Check for stop words
		next if ($word =~ /^(?:(?:http?|s?ftp))/i);  ##Check for url 
		next if ($word =~ /[<>]/);  ##Check for html contents - Mostly looking for < and >
		next if ($word =~ /[A-Z]/); ##Remove words having upper case
		$word =~ s/[0-9]//g;   ##Remove digits
		$word =~ s/[[:punct:]]//g;  ##Remove punctuations
		next if ( $word eq "" );
		####Use of Porter Stemmers logic to remove morphological variations
		my $stemword=Lingua::Stem::En::stem( {-words => [$word] });
		#push(@words_final, @$stemword) unless grep{$_ eq @$stemword} @words_final;
		my $finword=@$stemword[0];
		$count{$finword}++;
	}
	return %count;
}

sub preprocess_file{
	my $file=$_[0];
	open my $handle, '<', $file;
	my %file_words;
	(my @lines = <$handle>);
	close $handle;
	foreach my $line (@lines){
		#print "Line : $line \n";
		my %line_wrds=cleanup_line($line);
		#print Dumper %line_wrds;
		foreach my $str (keys %line_wrds){
			$file_words{$str}=$file_words{$str}+$line_wrds{$str}
		}
	}
	#print Dumper %file_words;
	#my %hash   = map { $_, 1 } @all_words;
	#my @uniq_words = keys %hash;
	#print "@uniq_words\n";
	return %file_words;
}


open(FH, '>', "out_file.log" ) or die $!;

print "Preprocessing text files in folder $ARGV[0]\n";
my %dict;
my @processed_file;
my $pf_cnt=0;
foreach my $file (@files){
	if ($file =~ m/.txt$/){
		$pf_cnt++;
		print "Processing File :$file \n";
		print FH "Doc_$pf_cnt = $file\n";
		my %words_in_file=preprocess_file($file);
		#print Dumper %words_in_file;
		foreach my $wrd (keys %words_in_file) {
			$dict{$wrd}{$file}=$words_in_file{$wrd}
		}
		push (@processed_file, $file);
		#print FH "Words contained in File - $file are \n";
		#print FH join("\n", @words_in_file), "\n";
	}
}
my $file_cnt=0;
printf FH "|%-30s | ", "Term";
foreach my $p_file (@processed_file) {
	$file_cnt++;
	print FH "Doc_${file_cnt} | ";
	foreach my $wrd1 (keys %dict){
		next if (exists $dict{$wrd1}{$p_file});
		$dict{$wrd1}{$p_file}=0;
	}
}
print FH "\n";
print FH "\n";
#foreach my $wrd (sort keys %dict){
#	foreach my $file (sort keys %{ $dict{$wrd} } ) {
#		printf " %s : %s : %s \n", $wrd , $file , $dict{$wrd}{$file};
		#	}
#}
foreach my $wrd (sort keys %dict) {
	printf FH "|%-30s |", $wrd;
	foreach my $p_file (@processed_file) {
		print FH " $dict{$wrd}{$p_file} \t |";
	}
	print FH "\n";
}
print "Done\n";
print "Output in out_file.log\n";
close (FH)
